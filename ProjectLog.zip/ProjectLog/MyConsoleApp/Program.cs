﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using ExtensibleLogger;

namespace MyConsoleApp
{
    public class Program
    {
        Logger _logger = Logger.MyLoggerInstance();
        static void Main(string[] args)
        {
            Program progObj = new Program();
            string myName = progObj.GetFulleName("NItesh", null);
            Console.WriteLine("My Name is: " + myName);
            Console.ReadLine();
        }

        //sample method to test
        public string GetFulleName(string firstName, string lastName) {
            string fullName = string.Empty;
            try
            {

                if (firstName != null && lastName != null)
                {
                    fullName = firstName + " " + lastName;
                }
                else
                {
                    throw new NullReferenceException();
                }
                return fullName;
            }
            catch (NullReferenceException ex) 
            {
                //written log in multiple way
                _logger.WriteLog(ex);
                _logger.WriteLog("GetFullName", ex);
                _logger.WriteLog("Exeption occured in GetFullName");
                return fullName;
            }
            catch (Exception ex)
            {
                //written log in multiple way
                _logger.WriteLog(ex);
                _logger.WriteLog("GetFullName", ex);
                _logger.WriteLog("Exeption occured in GetFullName");
                return fullName;
            }
        }
    }
}
