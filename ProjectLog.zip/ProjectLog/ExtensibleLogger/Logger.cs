﻿using System;

using System.Configuration;
using System.IO;

namespace ExtensibleLogger
{
    //sigleton pattern to maintin single object
    public sealed class Logger
    {
        private string logFolderName = ConfigurationManager.AppSettings["LogFolderPath"];
        string DateTimeNow = DateTime.UtcNow.ToString();
        string DateToday = DateTime.UtcNow.Date.ToString("MM-dd-yyyy");
        private Logger() { }
        public static Logger GetInstace = null;
        public static Logger MyLoggerInstance()
        {

            if (GetInstace == null)
            {
                GetInstace = new Logger();
                return GetInstace;
            }
            else
            {
                return GetInstace;
            }
        }

        #region Write log only string
        public void WriteLog(string message)
        {
            // If Not Created then Create
            CheckAndCreateFolder(logFolderName);

            string fileLogPath = logFolderName + DateToday + ".txt";
            //StramWriter Will write the log if file present if not then it will create first then write
            using (StreamWriter streamWrite = new StreamWriter(fileLogPath, true))
            {
                streamWrite.WriteLine(DateTimeNow + " - "+ message);
            }
        }
        #endregion

        #region  Write log only exception
        public void WriteLog(Exception exeption)
        {

            string DateToday = DateTime.UtcNow.Date.ToString("MM-dd-yyyy");

            // If Not Created then Create
            CheckAndCreateFolder(logFolderName);


            string fileLogPath = logFolderName + DateToday + ".txt";
            //StramWriter Will write the log if file present if not then it will create first then write
            using (StreamWriter streamWrite = new StreamWriter(fileLogPath, true))
            {
                streamWrite.WriteLine(DateTimeNow + " - " + exeption);
            }
        }
        #endregion

        #region Write log string with exception
        public void WriteLog(string message,Exception exeption)
        {
            string DateTimeNow = DateTime.UtcNow.ToString();
            string DateToday = DateTime.UtcNow.Date.ToString("MM-dd-yyyy");
            
            // If Not Created then Create
            CheckAndCreateFolder(logFolderName);

            string fileLogPath = logFolderName + DateToday + ".txt";
            //StramWriter Will write the log if file present if not then it will create first then write
            using (StreamWriter streamWrite = new StreamWriter(fileLogPath, true))
            {
                streamWrite.WriteLine(DateTimeNow + " - " + message + " : "+ exeption);
            }
        }
        #endregion

        

        #region
        private void CheckAndCreateFolder(string folderPath)
        {
            string logFolderName = ConfigurationManager.AppSettings["LogFolderPath"];
            if (!Directory.Exists(folderPath))
            {
                Directory.CreateDirectory(folderPath);
            }
        }
        #endregion
    }
}
